package com.springhw.springhw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringhwApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringhwApplication.class, args);
	}

}
