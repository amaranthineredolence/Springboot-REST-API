package com.springhw.springhw.service;

import com.springhw.springhw.mode.user;

import java.util.List;
import java.util.Optional;

public interface UserService {
    List<user> findAllUser();
    Optional<user> findById(Long id);
    user saveUser(user user);
    user updateUser(user user);
    void deleteUser(Long id);
}
