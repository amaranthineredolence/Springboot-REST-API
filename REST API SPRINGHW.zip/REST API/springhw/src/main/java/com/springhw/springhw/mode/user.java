package com.springhw.springhw.mode;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import java.time.LocalDate;

@Entity
@Table(name = "sample")
public class user {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "Id")
    private string id;
    @Column(name = "name")
    private string name;
    @Column(name = "surname")
    private string surname;
    @Column(name = "identityNumber")
    private string identityNumber;
    @Column(name = "birthDate")
    private LocalDate birthDate;
    @Column(name = "email")
    private string email;
    @Column(name = "status")
    private int status; //valid=0


    public user(){

    }


    public user(string id, string name, string surname, string identityNumber, LocalDate birthDate, string email, int status) {
        this.id = id;
        this.name = name;
        this.surname = surname;
        this.identityNumber = identityNumber;
        this.birthDate = birthDate;
        this.email = email;
        this.status = status;
    }

    public string getId() {
        return id;
    }

    public void setId(string id) {
        this.id = id;
    }

    public string getName() {
        return name;
    }

    public void setName(string name) {
        this.name = name;
    }

    public string getSurname() {
        return surname;
    }

    public void setSurname(string surname) {
        this.surname = surname;
    }

    public string getIdentityNumber() {
        return identityNumber;
    }

    public void setIdentityNumber(string identityNumber) {
        this.identityNumber = identityNumber;
    }

    public LocalDate getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(LocalDate birthDate) {
        this.birthDate = birthDate;
    }

    public string getEmail() {
        return email;
    }

    public void setEmail(string email) {
        this.email = email;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }
}
