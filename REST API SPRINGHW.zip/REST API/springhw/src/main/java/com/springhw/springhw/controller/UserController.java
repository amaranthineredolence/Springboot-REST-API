package com.springhw.springhw.controller;

import com.springhw.springhw.mode.user;
import com.springhw.springhw.service.UserService;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;

    }

    @GetMapping
    public List<user> findAllUser() {
        return userService.findAllUser();
    }

    @GetMapping("/{id}")
    public Optional<user> findUserById(@PathVariable("id") Long id){
        return userService.findById(id);

    }

    @PostMapping
    public user saveUser(@RequestBody user user) {
        return userService.saveUser(user);

    }

    @PutMapping
    public user updateUser(@RequestBody user user) {
        return userService.updateUser(user);


    }

    @DeleteMapping("/{id}")
    public void deleteUser(@PathVariable("id") Long id){
        userService.deleteUser(id);
    }



}
