package com.springhw.springhw;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringhwApplicationTests {

	@Test
	void contextLoads() {
	}

}
